#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Task structure
struct Task
{
    string description;
    bool completed;
};

// Function to display the to-do list
void displayToDoList(const vector<Task>& list)
{
    cout << "\nTo-Do List:\n";
    if (list.empty())
    {
        cout << "No tasks found.\n";
    }
    else
    {
        for (int i = 0; i < list.size(); ++i)
        {
            cout << i + 1 << ". " << (list[i].completed ? "[x] " : "[ ] ") << list[i].description << endl;
        }
    }
}

// Function to add a task to the to-do list
void addTask(vector<Task>& list)
{
    Task task;
    cout << "\nEnter a task to add to the to-do list: ";
    getline(cin, task.description);
    task.completed = false;
    list.push_back(task);
    cout << "Task added successfully.\n";
}

// Function to mark a task as completed
void markAsCompleted(vector<Task>& list)
{
    int num;
    displayToDoList(list);
    cout << "\nEnter the number of the task to mark as completed: ";
    cin >> num;
    if (num > 0 && num <= list.size())
    {
        if (!list[num - 1].completed)
        {
            list[num - 1].completed = true;
            cout << "Task marked as completed successfully.\n";
        }
        else
        {
            cout << "Task is already marked as completed.\n";
        }
    }
    else
    {
        cout << "Invalid task number. No task marked as completed.\n";
    }
}

// Function to delete a task from the to-do list
void deleteTask(vector<Task>& list)
{
    int num;
    displayToDoList(list);
    cout << "\nEnter the number of the task to delete: ";
    cin >> num;
    if (num > 0 && num <= list.size())
    {
        list.erase(list.begin() + num - 1);
        cout << "Task deleted successfully.\n";
    }
    else
    {
        cout << "Invalid task number. No task deleted.\n";
    }
}

int main()
{
    vector<Task> toDoList;
    int choice;

    while (true)
    {
        cout << "\nTo-Do List Manager\n";
        cout << "1. View tasks\n";
        cout << "2. Add task\n";
        cout << "3. Mark as completed\n";
        cout << "4. Delete task\n";
        cout << "5. Quit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                displayToDoList(toDoList);
                break;
            case 2:
                addTask(toDoList);
                break;
            case 3:
                markAsCompleted(toDoList);
                break;
            case 4:
                deleteTask(toDoList);
                break;
            case 5:
                cout << "Quitting To-Do List Manager.\n";
                return 0;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    }

    return 0;
}
