#include <iostream>
#include <ctime>
#include <cstdlib>

int main()
{
    srand(time(0)); // seed the random number generator
    int number = rand() % 100; // generate a random number between 0 and 99
    int guess;
    int tries = 0;

    std::cout << "Guess the number between 0 and 99.\n";

    while (true)
    {
        std::cin >> guess;
        tries++;

        if (guess < 0 || guess > 99)
        {
            std::cout << "Your guess is out of range. Please try again.\n";
        }
        else if (guess < number)
        {
            std::cout << "Your guess is too low. Try again.\n";
        }
        else if (guess > number)
        {
            std::cout << "Your guess is too high. Try again.\n";
        }
        else
        {
            std::cout << "Congratulations! You guessed the number in " << tries << " tries.\n";
            break;
        }
    }

    return 0;
}
