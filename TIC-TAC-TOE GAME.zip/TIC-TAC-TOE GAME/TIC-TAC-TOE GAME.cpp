#include <iostream>
#include <vector>
#include <string>

using namespace std;

class TicTacToe {
private:
    vector<vector<char> > board;
    char currentPlayer;
    bool gameOver;

public:
    TicTacToe() : board(3, vector<char>(3, ' ')), currentPlayer('X'), gameOver(false) {}

    void displayBoard() {
        cout << "-------------" << endl;
        for (int i = 0; i < 3; ++i) {
            cout << "| ";
            for (int j = 0; j < 3; ++j) {
                cout << board[i][j] << " | ";
            }
            cout << endl << "-------------" << endl;
        }
    }

    void switchPlayer() {
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    bool isValidMove(int row, int col) {
        if (row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ')
            return true;
        return false;
    }

    void makeMove(int row, int col) {
        if (isValidMove(row, col)) {
            board[row][col] = currentPlayer;
            checkWin(row, col);
            switchPlayer();
        } else {
            cout << "Invalid move! Try again." << endl;
        }
    }

    void checkWin(int row, int col) {
        // Check row
        if (board[row][0] == board[row][1] && board[row][1] == board[row][2])
            gameOver = true;
        // Check column
        if (board[0][col] == board[1][col] && board[1][col] == board[2][col])
            gameOver = true;
        // Check diagonals
        if ((board[0][0] == board[1][1] && board[1][1] == board[2][2]) ||
            (board[0][2] == board[1][1] && board[1][1] == board[2][0]))
            gameOver = true;
    }

    bool isGameOver() {
        return gameOver;
    }

    bool isDraw() {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (board[i][j] == ' ')
                    return false;
            }
        }
        return true;
    }

    void displayResult() {
        if (isGameOver()) {
            cout << "Player " << currentPlayer << " wins!" << endl;
        } else if (isDraw()) {
            cout << "It's a draw!" << endl;
        }
    }

    void play() {
        int row, col;
        while (!isGameOver() && !isDraw()) {
            displayBoard();
            cout << "Player " << currentPlayer << "'s turn. Enter row (0-2) and column (0-2): ";
            cin >> row >> col;
            makeMove(row, col);
        }
        displayBoard();
        displayResult();
    }
};

int main() {
    char playAgain = 'y';
    while (playAgain == 'y' || playAgain == 'Y') {
        TicTacToe game;
        game.play();
        cout << "Play again? (y/n): ";
        cin >> playAgain;
    }
    cout << "Thanks for playing!" << endl;
    return 0;
}

